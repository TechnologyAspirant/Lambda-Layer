def validateAcct(AcctNo):
    if len(AcctNo)==10:
        return 'PASS'
    else:
        return 'FAIL'